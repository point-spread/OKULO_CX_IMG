from . import transformer, dataloader

def calibration_transformers(input_size, input_layout, input_format, data_type):
    """
    step：
        1、pad resize to 640 * 640
        2、NHWC to NCHW
        3、bgr to rgb
    """
    transformers = [
        transformer.PadResizeTransformer(target_size=input_size),
    ]
    if input_layout[-3:].upper() == "CHW":
        transformers.append(transformer.HWC2CHWTransformer())
    if data_type == "uint8":
        transformers.append(transformer.F32ToU8Transformer())
    if input_format.upper() == "RGB":
        transformers.append(transformer.BGR2RGBTransformer(input_layout[-3:].upper()))
        pass
    
        
    return transformers


def original_infer_transformers(input_shape, input_layout="NHWC"):
    """
    step：
        1、pad resize to target_size(input_shape)
        2、bgr to rgb
        3、rgb to nv12
        3、nv12 to yuv444
    :param input_shape: input shape(target size)
    :param input_layout: NCHW / NHWC
    """

    transformers = [
        transformer.PadResizeTransformer(target_size=input_shape),
        # transformer.BGR2RGBTransformer(data_format=input_layout[-3:]),
        # transformer.NormalizeTransformer(),
        transformer.RGB2NV12Transformer(data_format=input_layout[-3:]),
        transformer.NV12ToYUV444Transformer(target_size=input_shape,
                                yuv444_output_layout=input_layout[1:]),
        transformer.F32ToU8Transformer()
        
    ]
    return transformers

def infer_image_preprocess(image_file, input_layout, input_shape):
    """
    image for single image inference
    note: imread_mode [skimage / opencv]
        opencv read image as 8-bit unsigned integers BGR in range [0, 255]
        skimage read image as float32 RGB in range [0, 1]
        make sure to use the same imread_mode as the model training
    :param image_file: image file
    :param input_layout: NCHW / NHWC
    :param input_shape: input shape（target size）
    :return: origin image, processed image (uint8, 0-255)
    """
    transformers = original_infer_transformers(input_shape, input_layout)
    origin_image, processed_image = dataloader.SingleImageDataLoaderWithOrigin(
        transformers, image_file, imread_mode="opencv")
    return origin_image, processed_image

def eval_image_preprocess(image_path, annotation_path, input_shape,
                          input_layout):
    """
    image for full scale evaluation
    note: imread_mode [skimage / opencv]
        opencv read image as 8-bit unsigned integers BGR in range [0, 255]
        skimage read image as float32 RGB in range [0, 1]
        make sure to use the same imread_mode as the model training
    :param image_path: image path
    :param annotation_path: annotation path
    :param input_shape: input shape（target size）
    :param input_layout: input layout
    :return: data loader
    """
    transformers = original_infer_transformers(input_shape, input_layout)
    data_loader = dataloader.COCODataLoader(transformers,
                                 image_path,
                                 annotation_path,
                                 imread_mode='opencv')

    return data_loader
